package com.shototo;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.List;

public class ShotgunItem extends Item {
    // ---- tweak these ----
    private static final float DAMAGE = 15.0F;      // damage per shot
    private static final int MAX_AMMO = 8;          // shells per magazine
    private static final int FIRE_COOLDOWN = 4;     // ticks between shots (20 ticks = 1 sec)
    private static final int RELOAD_TICKS = 40;     // reload time
    private static final double RANGE = 32.0D;      // blocks
    // ---------------------

    public ShotgunItem(Properties props) {
        super(props);
    }

    private static int getAmmo(ItemStack stack) {
        CompoundTag tag = stack.getTag();
        return (tag != null && tag.contains("Ammo")) ? tag.getInt("Ammo") : MAX_AMMO;
    }

    private static void setAmmo(ItemStack stack, int ammo) {
        stack.getOrCreateTag().putInt("Ammo", ammo);
    }

    private static boolean isReloading(ItemStack stack) {
        CompoundTag tag = stack.getTag();
        return tag != null && tag.contains("ReloadEnd");
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);

        if (isReloading(stack)) {
            return InteractionResultHolder.fail(stack);
        }

        // Shift + right click = manual reload. Empty mag = auto reload.
        int ammo = getAmmo(stack);
        if ((player.isShiftKeyDown() && ammo < MAX_AMMO) || ammo <= 0) {
            startReload(level, player, stack);
            return InteractionResultHolder.success(stack);
        }

        if (!level.isClientSide) {
            fire((ServerLevel) level, player);
            setAmmo(stack, ammo - 1);
        }
        player.getCooldowns().addCooldown(this, FIRE_COOLDOWN);
        return InteractionResultHolder.success(stack);
    }

    private void startReload(Level level, Player player, ItemStack stack) {
        player.getCooldowns().addCooldown(this, RELOAD_TICKS);
        if (!level.isClientSide) {
            stack.getOrCreateTag().putLong("ReloadEnd", level.getGameTime() + RELOAD_TICKS);
            level.playSound(null, player.getX(), player.getY(), player.getZ(),
                    ShototoMod.RELOAD_SOUND.get(), SoundSource.PLAYERS, 1.0F, 1.0F);
        }
    }

    @Override
    public void inventoryTick(ItemStack stack, Level level, Entity entity, int slot, boolean selected) {
        if (level.isClientSide || !isReloading(stack)) return;
        if (level.getGameTime() >= stack.getTag().getLong("ReloadEnd")) {
            stack.getTag().remove("ReloadEnd");
            setAmmo(stack, MAX_AMMO);
        }
    }

    private void fire(ServerLevel level, Player player) {
        Vec3 eye = player.getEyePosition();
        Vec3 look = player.getLookAngle();

        // Sound
        level.playSound(null, player.getX(), player.getY(), player.getZ(),
                ShototoMod.FIRE_SOUND.get(), SoundSource.PLAYERS, 1.0F, 1.0F);

        // Crit particles at the end of the barrel
        Vec3 right = look.cross(new Vec3(0, 1, 0)).normalize();
        Vec3 muzzle = eye.add(look.scale(1.4)).add(right.scale(0.3)).add(0, -0.25, 0);
        level.sendParticles(ParticleTypes.CRIT, muzzle.x, muzzle.y, muzzle.z, 8, 0.08, 0.08, 0.08, 0.15);

        // Hitscan: stop at the first block, hit the first entity before it
        Vec3 end = eye.add(look.scale(RANGE));
        HitResult blockHit = level.clip(new ClipContext(eye, end,
                ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
        double dist = blockHit.getType() == HitResult.Type.MISS ? RANGE : blockHit.getLocation().distanceTo(eye);
        Vec3 rayEnd = eye.add(look.scale(dist));

        AABB box = player.getBoundingBox().expandTowards(look.scale(dist)).inflate(1.0);
        EntityHitResult hit = ProjectileUtil.getEntityHitResult(player, eye, rayEnd, box,
                e -> !e.isSpectator() && e.isPickable() && e != player, dist * dist);

        if (hit != null) {
            Entity target = hit.getEntity();
            target.invulnerableTime = 0; // lets rapid fire damage every shot
            target.hurt(player.damageSources().playerAttack(player), DAMAGE);
        }
    }

    @Override
    public boolean canAttackBlock(net.minecraft.world.level.block.state.BlockState state, Level level,
                                  net.minecraft.core.BlockPos pos, Player player) {
        return false;
    }

    @Override
    public boolean shouldCauseReequipAnimation(ItemStack oldStack, ItemStack newStack, boolean slotChanged) {
        return slotChanged; // don't bob the gun every time ammo changes
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal(isReloading(stack) ? "Reloading..." : "Ammo: " + getAmmo(stack) + "/" + MAX_AMMO));
        tooltip.add(Component.literal("Hold right-click to fire. Shift + right-click to reload."));
    }
}
